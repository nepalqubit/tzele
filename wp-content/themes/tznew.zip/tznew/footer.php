<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package TZnew
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer bg-gray-800 text-white py-12">
		<div class="container mx-auto px-4">
			<div class="footer-widgets grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
				<div class="footer-widget-1">
					<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
						<?php dynamic_sidebar( 'footer-1' ); ?>
					<?php else: ?>
						<h3 class="widget-title text-xl font-bold mb-4"><?php esc_html_e( 'About Us', 'tznew' ); ?></h3>
						<div class="widget-content">
							<p class="mb-4"><?php echo get_bloginfo( 'description' ); ?></p>
							<?php tznew_company_info(); ?>
						</div>
					<?php endif; ?>
				</div>
				<div class="footer-widget-2">
					<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
						<?php dynamic_sidebar( 'footer-2' ); ?>
					<?php else: ?>
						<h3 class="widget-title text-xl font-bold mb-4"><?php esc_html_e( 'Quick Links', 'tznew' ); ?></h3>
						<div class="widget-content">
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer',
									'menu_class'     => 'footer-menu space-y-2',
									'depth'          => 1,
								)
							);
							?>
						</div>
					<?php endif; ?>
				</div>
				<div class="footer-widget-3">
					<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
						<?php dynamic_sidebar( 'footer-3' ); ?>
					<?php else: ?>
						<h3 class="widget-title text-xl font-bold mb-4"><?php esc_html_e( 'Newsletter', 'tznew' ); ?></h3>
						<div class="widget-content">
							<p class="mb-4"><?php esc_html_e( 'Subscribe to our newsletter to receive updates and news.', 'tznew' ); ?></p>
							<!-- Newsletter form would go here, typically added via a widget or plugin -->
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="site-info border-t border-gray-700 pt-6 flex flex-wrap justify-between items-center">
				<div class="copyright">
					&copy; <?php echo date_i18n( 'Y' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
					<span class="sep"> | </span>
					<?php
					/* translators: 1: Theme name, 2: Theme author. */
					printf( esc_html__( 'Theme: %1$s by %2$s.', 'tznew' ), 'TZnew', '<a href="https://techzeninc.com">Santosh Baral</a>' );
					?>
				</div>
				<div class="social-links flex space-x-4">
					<?php
					// Display social links if ACF fields are available
					if (function_exists('get_field')) :
						$facebook = get_field('facebook_url', 'option');
						$twitter = get_field('twitter_url', 'option');
						$instagram = get_field('instagram_url', 'option');
						$linkedin = get_field('linkedin_url', 'option');
						
						if ($facebook) : ?>
							<a href="<?php echo esc_url($facebook); ?>" target="_blank" rel="noopener noreferrer" class="text-white hover:text-blue-400"><span class="dashicons dashicons-facebook-alt"></span></a>
						<?php endif; 
						if ($twitter) : ?>
							<a href="<?php echo esc_url($twitter); ?>" target="_blank" rel="noopener noreferrer" class="text-white hover:text-blue-400"><span class="dashicons dashicons-twitter"></span></a>
						<?php endif; 
						if ($instagram) : ?>
							<a href="<?php echo esc_url($instagram); ?>" target="_blank" rel="noopener noreferrer" class="text-white hover:text-blue-400"><span class="dashicons dashicons-instagram"></span></a>
						<?php endif; 
						if ($linkedin) : ?>
							<a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer" class="text-white hover:text-blue-400"><span class="dashicons dashicons-linkedin"></span></a>
						<?php endif; 
					endif; ?>
				</div>
			</div><!-- .site-info -->
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>