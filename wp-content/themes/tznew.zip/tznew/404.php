<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package TZnew
 */

get_header();
?>

<main id="primary" class="site-main container mx-auto py-16 px-4 text-center">

	<section class="error-404 not-found max-w-2xl mx-auto">
		<header class="page-header mb-8">
			<h1 class="page-title text-5xl font-bold mb-4"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'tznew' ); ?></h1>
		</header><!-- .page-header -->

		<div class="page-content prose mx-auto mb-12">
			<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'tznew' ); ?></p>

			<?php get_search_form(); ?>

			<div class="mt-12">
				<h2 class="text-2xl font-semibold mb-4"><?php esc_html_e( 'Popular Destinations', 'tznew' ); ?></h2>
				
				<?php
				// Display popular treks or tours
				$popular_args = array(
					'post_type'      => array('trekking', 'tours'),
					'posts_per_page' => 3,
					'orderby'        => 'meta_value_num',
					'meta_key'       => 'views', // Assuming you have a views counter
					'order'          => 'DESC',
				);
				
				$popular_query = new WP_Query($popular_args);
				
				if ($popular_query->have_posts()) :
					?>
					<div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
						<?php
						while ($popular_query->have_posts()) :
							$popular_query->the_post();
							?>
							<div class="bg-white rounded-lg shadow-md overflow-hidden">
								<?php if (has_post_thumbnail()) : ?>
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('medium', array('class' => 'w-full h-40 object-cover')); ?>
									</a>
								<?php endif; ?>
								<div class="p-4">
									<h3 class="text-lg font-semibold mb-2">
										<a href="<?php the_permalink(); ?>" class="hover:text-blue-600 transition duration-300">
											<?php the_title(); ?>
										</a>
									</h3>
									<div class="text-sm text-gray-600 mb-3">
										<?php
										// Display post type specific meta
										if (get_post_type() === 'trekking') :
											$duration = get_field('duration');
											$difficulty = get_field('difficulty');
											if ($duration) echo esc_html($duration) . ' | ';
											if ($difficulty) echo esc_html($difficulty);
										elseif (get_post_type() === 'tours') :
											$duration = get_field('duration');
											$tour_type = get_field('tour_type');
											if ($duration) echo esc_html($duration) . ' | ';
											if ($tour_type) echo esc_html($tour_type);
										endif;
										?>
									</div>
									<a href="<?php the_permalink(); ?>" class="inline-block bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium py-1 px-3 rounded transition duration-300">
										<?php esc_html_e('View Details', 'tznew'); ?>
									</a>
								</div>
							</div>
							<?php
						endwhile;
						?>
					</div>
					<?php
					wp_reset_postdata();
				else :
					?>
					<p><?php esc_html_e('No popular destinations found.', 'tznew'); ?></p>
					<?php
				endif;
				?>
			</div>

			<div class="mt-12">
				<a href="<?php echo esc_url(home_url('/')); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300">
					<?php esc_html_e('Back to Homepage', 'tznew'); ?>
				</a>
			</div>
		</div><!-- .page-content -->
	</section><!-- .error-404 -->

</main><!-- #main -->

<?php
get_footer();