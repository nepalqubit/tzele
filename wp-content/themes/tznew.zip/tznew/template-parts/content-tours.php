<?php
/**
 * Template part for displaying tours posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package TZnew
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('bg-white rounded-lg shadow-md overflow-hidden'); ?>>
	<?php tznew_post_thumbnail('medium_large', 'w-full h-64 object-cover'); ?>
	
	<div class="entry-content p-6">
		<?php
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title text-3xl font-bold mb-4 text-blue-800">', '</h1>' );
			
			// Display meta information
			if (function_exists('get_field')) :
				?>
				<div class="tour-meta grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
					<?php
					// Duration
					if (get_field('duration')) : ?>
						<div class="tour-meta-item flex flex-col items-center justify-center p-3 bg-white rounded-lg shadow-sm">
							<span class="block text-sm text-gray-600 mb-1"><?php esc_html_e('Duration', 'tznew'); ?></span>
							<span class="font-medium text-lg"><?php echo esc_html(get_field('duration')); ?> <?php esc_html_e('Days', 'tznew'); ?></span>
						</div>
					<?php endif; ?>
					
					<?php
					// Tour Type
					$tour_types = get_the_terms(get_the_ID(), 'tour_type');
					if ($tour_types && !is_wp_error($tour_types) && !empty($tour_types)) : ?>
						<div class="tour-meta-item flex flex-col items-center justify-center p-3 bg-white rounded-lg shadow-sm">
							<span class="block text-sm text-gray-600 mb-1"><?php esc_html_e('Tour Type', 'tznew'); ?></span>
							<span class="font-medium text-lg"><?php echo esc_html($tour_types[0]->name ?? ''); ?></span>
						</div>
					<?php endif; ?>
					
					<?php
					// Group Size
					if (get_field('group_size')) : ?>
						<div class="tour-meta-item flex flex-col items-center justify-center p-3 bg-white rounded-lg shadow-sm">
							<span class="block text-sm text-gray-600 mb-1"><?php esc_html_e('Group Size', 'tznew'); ?></span>
							<span class="font-medium text-lg"><?php echo esc_html(get_field('group_size')); ?></span>
						</div>
					<?php endif; ?>
					
					<?php
					// Languages
					if (get_field('languages')) : ?>
						<div class="tour-meta-item flex flex-col items-center justify-center p-3 bg-white rounded-lg shadow-sm">
							<span class="block text-sm text-gray-600 mb-1"><?php esc_html_e('Languages', 'tznew'); ?></span>
							<span class="font-medium text-lg"><?php echo esc_html(get_field('languages')); ?></span>
						</div>
					<?php endif; ?>
				</div>
				
				<?php
				// Overview
				if (get_field('overview')) : ?>
					<div class="tour-overview mb-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
						<h2 class="text-2xl font-bold mb-4 text-blue-700 border-b pb-2"><?php esc_html_e('Overview', 'tznew'); ?></h2>
						<div class="prose max-w-none text-gray-700">
							<?php echo wp_kses_post(get_field('overview')); ?>
						</div>
					</div>
				<?php endif; ?>
				
				<?php
				// Highlights
				if (have_rows('highlights')) : ?>
					<div class="tour-highlights mb-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
						<h2 class="text-2xl font-bold mb-4 text-blue-700 border-b pb-2"><?php esc_html_e('Highlights', 'tznew'); ?></h2>
						<ul class="list-disc pl-6 space-y-3 text-gray-700">
							<?php while (have_rows('highlights')) : the_row(); ?>
								<li class="text-lg"><?php echo wp_kses_post(get_sub_field('highlight')); ?></li>
							<?php endwhile; ?>
						</ul>
					</div>
				<?php endif; ?>
				
				<?php
				// Itinerary
				if (have_rows('itinerary')) : ?>
					<div class="tour-itinerary mb-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
						<h2 class="text-2xl font-bold mb-4 text-blue-700 border-b pb-2"><?php esc_html_e('Itinerary', 'tznew'); ?></h2>
						<div class="space-y-6">
							<?php $day_count = 1; while (have_rows('itinerary')) : the_row(); ?>
								<div class="itinerary-day p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500 hover:shadow-md transition duration-300">
									<h3 class="text-xl font-bold mb-2 text-blue-800"><?php esc_html_e('Day', 'tznew'); ?> <?php echo $day_count; ?>: <?php echo esc_html(get_sub_field('title')); ?></h3>
									<div class="prose max-w-none text-gray-700">
										<?php echo wp_kses_post(get_sub_field('description')); ?>
									</div>
									<?php if (get_sub_field('accommodation') || get_sub_field('meals')) : ?>
										<div class="itinerary-details mt-4 pt-4 border-t border-blue-200 grid grid-cols-1 md:grid-cols-2 gap-4">
											<?php if (get_sub_field('accommodation')) : ?>
												<div class="flex items-center">
													<span class="text-sm font-semibold text-blue-700 block mr-2"><?php esc_html_e('Accommodation:', 'tznew'); ?></span>
													<span class="text-gray-700"><?php echo esc_html(get_sub_field('accommodation')); ?></span>
												</div>
											<?php endif; ?>
											<?php if (get_sub_field('meals')) : ?>
												<div class="flex items-center">
													<span class="text-sm font-semibold text-blue-700 block mr-2"><?php esc_html_e('Meals:', 'tznew'); ?></span>
													<span class="text-gray-700"><?php echo esc_html(get_sub_field('meals')); ?></span>
												</div>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php $day_count++; endwhile; ?>
						</div>
					</div>
				<?php endif; ?>
				
				<?php
				// Includes/Excludes
				if (get_field('includes') || get_field('excludes')) : ?>
					<div class="tour-includes-excludes mb-8 grid grid-cols-1 md:grid-cols-2 gap-8">
						<?php if (get_field('includes')) : ?>
							<div class="tour-includes bg-green-50 p-6 rounded-lg shadow-sm border border-green-100">
								<h2 class="text-2xl font-bold mb-4 text-green-700 border-b border-green-200 pb-2"><?php esc_html_e('Includes', 'tznew'); ?></h2>
								<div class="list-content text-gray-700">
									<?php echo wp_kses_post(get_field('includes')); ?>
								</div>
							</div>
						<?php endif; ?>
						
						<?php if (get_field('excludes')) : ?>
							<div class="tour-excludes bg-red-50 p-6 rounded-lg shadow-sm border border-red-100">
								<h2 class="text-2xl font-bold mb-4 text-red-700 border-b border-red-200 pb-2"><?php esc_html_e('Excludes', 'tznew'); ?></h2>
								<div class="list-content text-gray-700">
									<?php echo wp_kses_post(get_field('excludes')); ?>
								</div>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				
				<?php 
				$gallery = get_field('gallery');
				if ($gallery && is_array($gallery) && !empty($gallery)) : ?>
					<div class="tour-gallery mb-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
						<h2 class="text-2xl font-bold mb-4 text-blue-700 border-b pb-2"><?php esc_html_e('Gallery', 'tznew'); ?></h2>
						<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
							<?php foreach ($gallery as $image) : 
								if (!is_array($image) || empty($image['url'])) continue; ?>
								<a href="<?php echo esc_url($image['url']); ?>" class="gallery-item hover:opacity-90 transition duration-300 transform hover:scale-105">
									<img src="<?php echo esc_url($image['sizes']['medium'] ?? $image['url']); ?>" alt="<?php echo esc_attr($image['alt'] ?? ''); ?>" class="w-full h-40 object-cover rounded shadow">
								</a>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
				
				<?php
				// Booking CTA
				tznew_booking_cta(get_the_ID());
				?>
				
			<?php endif; // End if function_exists('get_field') ?>
			
		else :
			// Archive view
			the_title( '<h2 class="entry-title text-xl font-bold mb-2"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark" class="text-blue-800 hover:text-blue-600 transition">', '</a></h2>' );
			
			// Display meta information for archive
			if (function_exists('get_field')) :
				?>
				<div class="tour-meta flex flex-wrap gap-4 mb-4 text-sm">
					<?php
					// Duration
					if (get_field('duration')) : ?>
						<div class="tour-meta-item flex items-center bg-blue-50 px-3 py-1 rounded-full">
							<span class="dashicons dashicons-clock text-blue-600 mr-1"></span>
							<span class="text-gray-700"><?php echo esc_html(get_field('duration')); ?> <?php esc_html_e('Days', 'tznew'); ?></span>
						</div>
					<?php endif; ?>
					
					<?php
					// Tour Type
					$tour_types = get_the_terms(get_the_ID(), 'tour_type');
					if ($tour_types && !is_wp_error($tour_types) && !empty($tour_types)) : ?>
						<div class="tour-meta-item flex items-center bg-blue-50 px-3 py-1 rounded-full">
							<span class="dashicons dashicons-category text-blue-600 mr-1"></span>
							<span class="text-gray-700"><?php echo esc_html($tour_types[0]->name ?? ''); ?></span>
						</div>
					<?php endif; ?>
					
					<?php
					// Region
					$regions = get_the_terms(get_the_ID(), 'region');
					if ($regions && !is_wp_error($regions) && !empty($regions)) : ?>
						<div class="tour-meta-item flex items-center bg-blue-50 px-3 py-1 rounded-full">
							<span class="dashicons dashicons-location text-blue-600 mr-1"></span>
							<span class="text-gray-700"><?php echo esc_html($regions[0]->name ?? ''); ?></span>
						</div>
					<?php endif; ?>
				</div>
				
				<?php
				// Short description
				if (get_field('overview')) : ?>
					<div class="tour-excerpt mb-4 text-gray-700">
						<?php echo wp_trim_words(get_field('overview'), 30, '...'); ?>
					</div>
				<?php endif; ?>
				
				<a href="<?php echo esc_url(get_permalink()); ?>" class="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition transform hover:scale-105 shadow-md">
					<?php esc_html_e('View Details', 'tznew'); ?>
				</a>
			<?php endif; // End if function_exists('get_field') ?>
		<?php endif; // End if is_singular() ?>
	</div>
</article>