<?php
/**
 * TZnew Theme functions and definitions
 *
 * @package TZnew
 * @author Santosh Baral
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define theme constants
define('TZNEW_VERSION', '1.0.0');
define('TZNEW_DIR', get_template_directory());
define('TZNEW_URI', get_template_directory_uri());

/**
 * Theme Setup
 */
function tznew_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('custom-logo');
    add_theme_support('woocommerce');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'tznew'),
        'footer' => esc_html__('Footer Menu', 'tznew'),
    ));
    
    // Set content width
    if (!isset($content_width)) {
        $content_width = 1200;
    }
}
add_action('after_setup_theme', 'tznew_setup');

/**
 * Enqueue scripts and styles
 */
function tznew_scripts() {
    // Enqueue Tailwind CSS
    wp_enqueue_style('tailwind', TZNEW_URI . '/assets/css/tailwind.min.css', array(), TZNEW_VERSION);
    
    // Enqueue theme stylesheet
    wp_enqueue_style('tznew-style', get_stylesheet_uri(), array(), TZNEW_VERSION);
    
    // Enqueue custom scripts
    wp_enqueue_script('tznew-scripts', TZNEW_URI . '/assets/js/scripts.js', array('jquery'), TZNEW_VERSION, true);
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'tznew_scripts');

/**
 * Include required files
 */
// Custom Post Types
require_once TZNEW_DIR . '/inc/post-types.php';

// ACF Integration
require_once TZNEW_DIR . '/inc/acf-integration.php';

// Theme Functions
require_once TZNEW_DIR . '/inc/theme-functions.php';

// REST API Integration
require_once TZNEW_DIR . '/inc/rest-api.php';

// WooCommerce Support
if (class_exists('WooCommerce')) {
    require_once TZNEW_DIR . '/inc/woocommerce.php';
}

// Elementor Support
if (did_action('elementor/loaded')) {
    require_once TZNEW_DIR . '/inc/elementor.php';
}

/**
 * Register widget area
 */
function tznew_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Sidebar', 'tznew'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Add widgets here.', 'tznew'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
    
    register_sidebar(array(
        'name'          => esc_html__('Footer 1', 'tznew'),
        'id'            => 'footer-1',
        'description'   => esc_html__('Add footer widgets here.', 'tznew'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => esc_html__('Footer 2', 'tznew'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Add footer widgets here.', 'tznew'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => esc_html__('Footer 3', 'tznew'),
        'id'            => 'footer-3',
        'description'   => esc_html__('Add footer widgets here.', 'tznew'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'tznew_widgets_init');

/**
 * Filter the excerpt length
 */
function tznew_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'tznew_excerpt_length');

/**
 * Filter the excerpt "read more" string
 */
function tznew_excerpt_more($more) {
    return '&hellip; <a href="' . esc_url(get_permalink()) . '" class="read-more">' . esc_html__('Read More', 'tznew') . '</a>';
}
add_filter('excerpt_more', 'tznew_excerpt_more');

/**
 * Add ACF options page
 */
if (function_exists('acf_add_options_page')) {
    acf_add_options_page(array(
        'page_title' => 'Theme Settings',
        'menu_title' => 'Theme Settings',
        'menu_slug'  => 'theme-settings',
        'capability' => 'edit_posts',
        'redirect'   => false
    ));
}

/**
 * Auto-load ACF JSON
 */
function tznew_acf_json_save_point($path) {
    return TZNEW_DIR . '/acf-json';
}
add_filter('acf/settings/save_json', 'tznew_acf_json_save_point');

function tznew_acf_json_load_point($paths) {
    $paths[] = TZNEW_DIR . '/acf-json';
    return $paths;
}
add_filter('acf/settings/load_json', 'tznew_acf_json_load_point');

/**
 * Disable Gutenberg editor for custom post types
 */
function tznew_disable_gutenberg($current_status, $post_type) {
    // Disable Gutenberg for custom post types
    if (in_array($post_type, array('trekking', 'tours', 'faq', 'blog'))) {
        return false;
    }
    return $current_status;
}
add_filter('use_block_editor_for_post_type', 'tznew_disable_gutenberg', 10, 2);

/**
 * Add custom admin columns for post types
 */
function tznew_add_admin_columns($columns) {
    $post_type = get_post_type();
    
    if ($post_type == 'trekking') {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => __('Title', 'tznew'),
            'trekking_id' => __('Trekking ID', 'tznew'),
            'difficulty' => __('Difficulty', 'tznew'),
            'region' => __('Region', 'tznew'),
            'date' => __('Date', 'tznew')
        );
    } elseif ($post_type == 'tours') {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => __('Title', 'tznew'),
            'tour_id' => __('Tour ID', 'tznew'),
            'type' => __('Type', 'tznew'),
            'region' => __('Region', 'tznew'),
            'date' => __('Date', 'tznew')
        );
    }
    
    return $columns;
}
add_filter('manage_posts_columns', 'tznew_add_admin_columns');

/**
 * Display custom admin column content
 */
function tznew_custom_column_content($column, $post_id) {
    if ($column == 'trekking_id') {
        echo 'TRK-' . $post_id;
    } elseif ($column == 'tour_id') {
        echo 'TOUR-' . $post_id;
    } elseif ($column == 'difficulty') {
        $difficulty = get_field('difficulty', $post_id);
        echo $difficulty ? esc_html($difficulty) : '-';
    } elseif ($column == 'region') {
        $region = get_field('region', $post_id);
        echo $region ? esc_html($region) : '-';
    } elseif ($column == 'type') {
        $type = get_field('tour_type', $post_id);
        echo $type ? esc_html($type) : '-';
    }
}
add_action('manage_posts_custom_column', 'tznew_custom_column_content', 10, 2);

/**
 * Add body classes
 */
function tznew_body_classes($classes) {
    // Add a class if WooCommerce is active
    if (class_exists('WooCommerce')) {
        $classes[] = 'woocommerce-active';
    }
    
    // Add a class if Elementor is active
    if (did_action('elementor/loaded')) {
        $classes[] = 'elementor-active';
    }
    
    return $classes;
}
add_filter('body_class', 'tznew_body_classes');