<?php
/**
 * The template for displaying the front page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package TZnew
 */

get_header();
?>

<main id="primary" class="site-main">

	<?php
	// Hero Section
	if (function_exists('get_field')) :
		$hero_title = get_field('hero_title', 'option');
		$hero_subtitle = get_field('hero_subtitle', 'option');
		$hero_image = get_field('hero_image', 'option');
		$hero_cta_text = get_field('hero_cta_text', 'option');
		$hero_cta_link = get_field('hero_cta_link', 'option');
		$hero_search_enabled = get_field('hero_search_enabled', 'option');
		
		$hero_image_url = (is_array($hero_image) && isset($hero_image['url'])) ? $hero_image['url'] : '';
		if (empty($hero_image_url)) {
			$hero_image_url = get_template_directory_uri() . '/assets/images/default-hero.jpg';
		}
		?>
		<section class="hero-section relative">
			<div class="hero-image relative h-screen min-h-[600px] max-h-[800px] bg-cover bg-center" style="background-image: url('<?php echo esc_url($hero_image_url); ?>')">
				<div class="absolute inset-0 bg-black bg-opacity-50"></div>
				<div class="container mx-auto px-4 h-full flex items-center relative z-10">
					<div class="text-center mx-auto max-w-3xl">
						<?php if ($hero_title) : ?>
							<h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4"><?php echo esc_html($hero_title); ?></h1>
						<?php else : ?>
							<h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4"><?php echo esc_html(get_bloginfo('name')); ?></h1>
						<?php endif; ?>
						
						<?php if ($hero_subtitle) : ?>
							<p class="text-xl md:text-2xl text-white mb-8"><?php echo esc_html($hero_subtitle); ?></p>
						<?php else : ?>
							<p class="text-xl md:text-2xl text-white mb-8"><?php echo esc_html(get_bloginfo('description')); ?></p>
						<?php endif; ?>
						
						<?php if ($hero_cta_text && $hero_cta_link) : ?>
							<a href="<?php echo esc_url($hero_cta_link); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300 mb-8">
								<?php echo esc_html($hero_cta_text); ?>
							</a>
						<?php endif; ?>
						
						<?php if ($hero_search_enabled) : ?>
							<div class="mt-4">
								<?php get_search_form(); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Featured Treks Section
	if (function_exists('get_field')) :
		$featured_treks_title = get_field('featured_treks_title', 'option');
		$featured_treks_subtitle = get_field('featured_treks_subtitle', 'option');
		$featured_treks_count = get_field('featured_treks_count', 'option') ?: 3;
		?>
		<section class="featured-treks py-16 bg-gray-50">
			<div class="container mx-auto px-4">
				<div class="text-center mb-12">
					<h2 class="text-3xl md:text-4xl font-bold mb-4">
						<?php echo $featured_treks_title ? esc_html($featured_treks_title) : esc_html__('Featured Treks', 'tznew'); ?>
					</h2>
					<?php if ($featured_treks_subtitle) : ?>
						<p class="text-xl text-gray-600"><?php echo esc_html($featured_treks_subtitle); ?></p>
					<?php endif; ?>
				</div>
				
				<?php
				$featured_args = array(
					'post_type'      => 'trekking',
					'posts_per_page' => intval($featured_treks_count),
					'meta_key'       => 'featured',
					'meta_value'     => '1',
				);
				
				$featured_query = new WP_Query($featured_args);
				
				if ($featured_query->have_posts()) :
					?>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						<?php
						while ($featured_query->have_posts()) :
							$featured_query->the_post();
							?>
							<div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2">
								<?php if (has_post_thumbnail()) : ?>
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('medium_large', array('class' => 'w-full h-56 object-cover')); ?>
									</a>
								<?php endif; ?>
								<div class="p-6">
									<h3 class="text-xl font-bold mb-2">
										<a href="<?php the_permalink(); ?>" class="hover:text-blue-600 transition duration-300">
											<?php the_title(); ?>
										</a>
									</h3>
									
									<div class="flex items-center text-sm text-gray-600 mb-3">
										<?php
										$duration = get_field('duration');
										$difficulty = get_field('difficulty');
										$regions = get_the_terms(get_the_ID(), 'region');
										
										if ($duration) : ?>
											<span class="mr-4"><i class="dashicons dashicons-clock"></i> <?php echo esc_html($duration); ?></span>
										<?php endif; ?>
										
										<?php if ($difficulty) : ?>
											<span class="mr-4"><i class="dashicons dashicons-performance"></i> <?php echo esc_html($difficulty); ?></span>
										<?php endif; ?>
										
										<?php if ($regions && !is_wp_error($regions)) : ?>
											<span><i class="dashicons dashicons-location"></i> <?php echo esc_html($regions[0]->name); ?></span>
										<?php endif; ?>
									</div>
									
									<?php
									$price = get_field('price');
									if ($price) :
										?>
										<div class="text-lg font-bold text-blue-600 mb-3">
											<?php echo esc_html($price); ?>
										</div>
									<?php endif; ?>
									
									<div class="mb-4 text-gray-700">
										<?php
										$overview = get_field('overview');
										if ($overview) {
											echo wp_trim_words(wp_strip_all_tags($overview), 20, '...');
										} else {
											the_excerpt();
										}
										?>
									</div>
									
									<a href="<?php the_permalink(); ?>" class="inline-block bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded transition duration-300">
										<?php esc_html_e('View Details', 'tznew'); ?>
									</a>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
					
					<div class="text-center mt-10">
						<a href="<?php echo esc_url(get_post_type_archive_link('trekking')); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300">
							<?php esc_html_e('View All Treks', 'tznew'); ?>
						</a>
					</div>
					<?php
					wp_reset_postdata();
				else :
					?>
					<p class="text-center"><?php esc_html_e('No featured treks found.', 'tznew'); ?></p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Popular Tours Section
	if (function_exists('get_field')) :
		$popular_tours_title = get_field('popular_tours_title', 'option');
		$popular_tours_subtitle = get_field('popular_tours_subtitle', 'option');
		$popular_tours_count = get_field('popular_tours_count', 'option') ?: 3;
		?>
		<section class="popular-tours py-16 bg-white">
			<div class="container mx-auto px-4">
				<div class="text-center mb-12">
					<h2 class="text-3xl md:text-4xl font-bold mb-4">
						<?php echo $popular_tours_title ? esc_html($popular_tours_title) : esc_html__('Popular Tours', 'tznew'); ?>
					</h2>
					<?php if ($popular_tours_subtitle) : ?>
						<p class="text-xl text-gray-600"><?php echo esc_html($popular_tours_subtitle); ?></p>
					<?php endif; ?>
				</div>
				
				<?php
				$popular_args = array(
					'post_type'      => 'tours',
					'posts_per_page' => intval($popular_tours_count),
					'meta_key'       => 'featured',
					'meta_value'     => '1',
				);
				
				$popular_query = new WP_Query($popular_args);
				
				if ($popular_query->have_posts()) :
					?>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						<?php
						while ($popular_query->have_posts()) :
							$popular_query->the_post();
							?>
							<div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2">
								<?php if (has_post_thumbnail()) : ?>
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('medium_large', array('class' => 'w-full h-56 object-cover')); ?>
									</a>
								<?php endif; ?>
								<div class="p-6">
									<h3 class="text-xl font-bold mb-2">
										<a href="<?php the_permalink(); ?>" class="hover:text-blue-600 transition duration-300">
											<?php the_title(); ?>
										</a>
									</h3>
									
									<div class="flex items-center text-sm text-gray-600 mb-3">
										<?php
										$duration = get_field('duration');
										$tour_type = get_field('tour_type');
										$regions = get_the_terms(get_the_ID(), 'region');
										
										if ($duration) : ?>
											<span class="mr-4"><i class="dashicons dashicons-clock"></i> <?php echo esc_html($duration); ?></span>
										<?php endif; ?>
										
										<?php if ($tour_type) : ?>
											<span class="mr-4"><i class="dashicons dashicons-category"></i> <?php echo esc_html($tour_type); ?></span>
										<?php endif; ?>
										
										<?php if ($regions && !is_wp_error($regions)) : ?>
											<span><i class="dashicons dashicons-location"></i> <?php echo esc_html($regions[0]->name); ?></span>
										<?php endif; ?>
									</div>
									
									<?php
									$price = get_field('price');
									if ($price) :
										?>
										<div class="text-lg font-bold text-blue-600 mb-3">
											<?php echo esc_html($price); ?>
										</div>
									<?php endif; ?>
									
									<div class="mb-4 text-gray-700">
										<?php
										$overview = get_field('overview');
										if ($overview) {
											echo wp_trim_words(wp_strip_all_tags($overview), 20, '...');
										} else {
											the_excerpt();
										}
										?>
									</div>
									
									<a href="<?php the_permalink(); ?>" class="inline-block bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded transition duration-300">
										<?php esc_html_e('View Details', 'tznew'); ?>
									</a>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
					
					<div class="text-center mt-10">
						<a href="<?php echo esc_url(get_post_type_archive_link('tours')); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300">
							<?php esc_html_e('View All Tours', 'tznew'); ?>
						</a>
					</div>
					<?php
					wp_reset_postdata();
				else :
					?>
					<p class="text-center"><?php esc_html_e('No popular tours found.', 'tznew'); ?></p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Destinations Section
	if (function_exists('get_field')) :
		$destinations_title = get_field('destinations_title', 'option');
		$destinations_subtitle = get_field('destinations_subtitle', 'option');
		?>
		<section class="destinations py-16 bg-gray-50">
			<div class="container mx-auto px-4">
				<div class="text-center mb-12">
					<h2 class="text-3xl md:text-4xl font-bold mb-4">
						<?php echo $destinations_title ? esc_html($destinations_title) : esc_html__('Popular Destinations', 'tznew'); ?>
					</h2>
					<?php if ($destinations_subtitle) : ?>
						<p class="text-xl text-gray-600"><?php echo esc_html($destinations_subtitle); ?></p>
					<?php endif; ?>
				</div>
				
				<?php
				// Get regions with image and count
				$regions = get_terms(array(
					'taxonomy' => 'region',
					'hide_empty' => true,
				));
				
				if (!empty($regions) && !is_wp_error($regions)) :
					?>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						<?php foreach ($regions as $region) : 
							$region_image = get_field('region_image', 'region_' . $region->term_id);
							$region_image_url = isset($region_image['url']) ? $region_image['url'] : '';
							
							if (empty($region_image_url)) {
								$region_image_url = get_template_directory_uri() . '/assets/images/default-region.jpg';
							}
							
							// Count posts in this region
							$count_args = array(
								'post_type' => array('trekking', 'tours'),
								'tax_query' => array(
									array(
										'taxonomy' => 'region',
										'field' => 'term_id',
										'terms' => $region->term_id,
									),
								),
								'posts_per_page' => -1,
							);
							
							$count_query = new WP_Query($count_args);
							$count = $count_query->found_posts;
							?>
							<div class="relative rounded-lg overflow-hidden shadow-lg group transition-transform duration-300 hover:-translate-y-2">
								<a href="<?php echo esc_url(get_term_link($region)); ?>">
									<div class="aspect-w-16 aspect-h-9">
										<img src="<?php echo esc_url($region_image_url); ?>" alt="<?php echo esc_attr($region->name); ?>" class="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110" />
									</div>
									<div class="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
									<div class="absolute bottom-0 left-0 p-6 text-white">
										<h3 class="text-2xl font-bold mb-2"><?php echo esc_html($region->name); ?></h3>
										<p class="text-sm">
											<?php printf(_n('%s Adventure', '%s Adventures', $count, 'tznew'), number_format_i18n($count)); ?>
										</p>
									</div>
								</a>
							</div>
						<?php endforeach; ?>
					</div>
					<?php
				else :
					?>
					<p class="text-center"><?php esc_html_e('No destinations found.', 'tznew'); ?></p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Testimonials Section
	if (function_exists('get_field')) :
		$testimonials_title = get_field('testimonials_title', 'option');
		$testimonials_subtitle = get_field('testimonials_subtitle', 'option');
		$testimonials = get_field('testimonials', 'option');
		?>
		<section class="testimonials py-16 bg-blue-600 text-white">
			<div class="container mx-auto px-4">
				<div class="text-center mb-12">
					<h2 class="text-3xl md:text-4xl font-bold mb-4">
						<?php echo $testimonials_title ? esc_html($testimonials_title) : esc_html__('What Our Clients Say', 'tznew'); ?>
					</h2>
					<?php if ($testimonials_subtitle) : ?>
						<p class="text-xl opacity-90"><?php echo esc_html($testimonials_subtitle); ?></p>
					<?php endif; ?>
				</div>
				
				<?php if ($testimonials) : ?>
					<div class="testimonial-slider max-w-4xl mx-auto">
						<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
							<?php foreach ($testimonials as $testimonial) : ?>
								<div class="bg-white bg-opacity-10 backdrop-blur-sm p-6 rounded-lg">
									<div class="mb-4 text-yellow-300">
										<?php
										// Display stars based on rating
										$rating = isset($testimonial['rating']) ? intval($testimonial['rating']) : 5;
										for ($i = 1; $i <= 5; $i++) {
											if ($i <= $rating) {
												echo '<i class="dashicons dashicons-star-filled"></i>';
											} else {
												echo '<i class="dashicons dashicons-star-empty"></i>';
											}
										}
										?>
									</div>
									<div class="italic mb-4">
										<?php echo esc_html($testimonial['content']); ?>
									</div>
									<div class="flex items-center">
										<?php if (isset($testimonial['photo']) && !empty($testimonial['photo']['url'])) : ?>
											<img src="<?php echo esc_url($testimonial['photo']['url']); ?>" alt="<?php echo esc_attr($testimonial['name']); ?>" class="w-12 h-12 rounded-full mr-4 object-cover" />
										<?php endif; ?>
										<div>
											<div class="font-bold"><?php echo esc_html($testimonial['name']); ?></div>
											<?php if (isset($testimonial['trip'])) : ?>
												<div class="text-sm opacity-90"><?php echo esc_html($testimonial['trip']); ?></div>
											<?php endif; ?>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php else : ?>
					<p class="text-center"><?php esc_html_e('No testimonials found.', 'tznew'); ?></p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Blog Section
	if (function_exists('get_field')) :
		$blog_title = get_field('blog_title', 'option');
		$blog_subtitle = get_field('blog_subtitle', 'option');
		$blog_count = get_field('blog_count', 'option') ?: 3;
		?>
		<section class="blog py-16 bg-white">
			<div class="container mx-auto px-4">
				<div class="text-center mb-12">
					<h2 class="text-3xl md:text-4xl font-bold mb-4">
						<?php echo $blog_title ? esc_html($blog_title) : esc_html__('Latest from Our Blog', 'tznew'); ?>
					</h2>
					<?php if ($blog_subtitle) : ?>
						<p class="text-xl text-gray-600"><?php echo esc_html($blog_subtitle); ?></p>
					<?php endif; ?>
				</div>
				
				<?php
				$blog_args = array(
					'post_type'      => 'blog',
					'posts_per_page' => intval($blog_count),
				);
				
				$blog_query = new WP_Query($blog_args);
				
				if ($blog_query->have_posts()) :
					?>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						<?php
						while ($blog_query->have_posts()) :
							$blog_query->the_post();
							?>
							<div class="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2">
								<?php if (has_post_thumbnail()) : ?>
									<a href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('medium_large', array('class' => 'w-full h-48 object-cover')); ?>
									</a>
								<?php endif; ?>
								<div class="p-6">
									<div class="flex items-center text-sm text-gray-500 mb-3">
										<span class="mr-3">
											<i class="dashicons dashicons-calendar-alt"></i> 
											<?php echo get_the_date(); ?>
										</span>
										<?php
										$tags = get_the_terms(get_the_ID(), 'acf_tag');
										if ($tags && !is_wp_error($tags)) :
											?>
											<span>
												<i class="dashicons dashicons-tag"></i>
												<?php echo esc_html($tags[0]->name); ?>
											</span>
											<?php
										endif;
										?>
									</div>
									
									<h3 class="text-xl font-bold mb-3">
										<a href="<?php the_permalink(); ?>" class="hover:text-blue-600 transition duration-300">
											<?php the_title(); ?>
										</a>
									</h3>
									
									<div class="mb-4 text-gray-700">
										<?php
										$content = get_field('content');
										if ($content) {
											echo wp_trim_words(wp_strip_all_tags($content), 20, '...');
										} else {
											the_excerpt();
										}
										?>
									</div>
									
									<a href="<?php the_permalink(); ?>" class="inline-block text-blue-600 hover:text-blue-800 font-medium transition duration-300">
										<?php esc_html_e('Read More', 'tznew'); ?> &rarr;
									</a>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
					
					<div class="text-center mt-10">
						<a href="<?php echo esc_url(get_post_type_archive_link('blog')); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300">
							<?php esc_html_e('View All Posts', 'tznew'); ?>
						</a>
					</div>
					<?php
					wp_reset_postdata();
				else :
					?>
					<p class="text-center"><?php esc_html_e('No blog posts found.', 'tznew'); ?></p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// CTA Section
	if (function_exists('get_field')) :
		$cta_title = get_field('cta_title', 'option');
		$cta_content = get_field('cta_content', 'option');
		$cta_button_text = get_field('cta_button_text', 'option');
		$cta_button_link = get_field('cta_button_link', 'option');
		$cta_background = get_field('cta_background', 'option');
		
		$cta_bg_url = isset($cta_background['url']) ? $cta_background['url'] : '';
		if (empty($cta_bg_url)) {
			$cta_bg_url = get_template_directory_uri() . '/assets/images/default-cta-bg.jpg';
		}
		?>
		<section class="cta relative py-20" style="background-image: url('<?php echo esc_url($cta_bg_url); ?>'); background-size: cover; background-position: center;">
			<div class="absolute inset-0 bg-blue-900 bg-opacity-80"></div>
			<div class="container mx-auto px-4 relative z-10 text-center text-white">
				<div class="max-w-3xl mx-auto">
					<?php if ($cta_title) : ?>
						<h2 class="text-3xl md:text-4xl font-bold mb-6"><?php echo esc_html($cta_title); ?></h2>
					<?php endif; ?>
					
					<?php if ($cta_content) : ?>
						<div class="text-xl mb-8"><?php echo wp_kses_post($cta_content); ?></div>
					<?php endif; ?>
					
					<?php if ($cta_button_text && $cta_button_link) : ?>
						<a href="<?php echo esc_url($cta_button_link); ?>" class="inline-block bg-white text-blue-900 hover:bg-gray-100 font-bold py-3 px-8 rounded-lg text-lg transition duration-300">
							<?php echo esc_html($cta_button_text); ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

</main><!-- #main -->

<?php
get_footer();