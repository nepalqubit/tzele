<div class="wrap revx-chatbot-admin">
    <h1>RevX Chatbot Settings</h1>
    
    <div class="revx-chatbot-admin-tabs">
        <button class="revx-chatbot-tab-button active" data-tab="settings">Settings</button>
        <button class="revx-chatbot-tab-button" data-tab="responses">Responses</button>
        <button class="revx-chatbot-tab-button" data-tab="training">Training</button>
        <button class="revx-chatbot-tab-button" data-tab="openrouter">OpenRouter API</button>
    </div>
    
    <div class="revx-chatbot-admin-content">
        <!-- Settings Tab -->
        <div class="revx-chatbot-tab-content active" id="settings-tab">
            <h2>General Settings</h2>
            <form id="revx-chatbot-settings-form">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="revx-chatbot-title">Chatbot Title</label></th>
                        <td>
                            <input type="text" id="revx-chatbot-title" name="title" value="<?php echo esc_attr(get_option('revx_chatbot_title', 'RevX Chatbot')); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="revx-chatbot-theme-color">Theme Color</label></th>
                        <td>
                            <input type="color" id="revx-chatbot-theme-color" name="theme_color" value="<?php echo esc_attr(get_option('revx_chatbot_theme_color', '#4a6cf7')); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="revx-chatbot-initial-message">Initial Message</label></th>
                        <td>
                            <input type="text" id="revx-chatbot-initial-message" name="initial_message" value="<?php echo esc_attr(get_option('revx_chatbot_initial_message', 'Hi there! How can I help you today?')); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="revx-chatbot-use-openrouter">Use OpenRouter API</label></th>
                        <td>
                            <input type="checkbox" id="revx-chatbot-use-openrouter" name="use_openrouter" <?php checked(get_option('revx_chatbot_use_openrouter', false)); ?>>
                            <p class="description">Enable OpenRouter API to better understand complex user queries.</p>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Save Settings</button>
                </p>
            </form>
        </div>
        
        <!-- Responses Tab -->
        <div class="revx-chatbot-tab-content" id="responses-tab">
            <h2>Current Responses</h2>
            <p>View and manage your chatbot's current responses.</p>
            <div id="revx-chatbot-responses-container">
                <div class="revx-chatbot-loading">Loading responses...</div>
            </div>
        </div>
        
        <!-- Training Tab -->
        <div class="revx-chatbot-tab-content" id="training-tab">
            <h2>Train Your Chatbot</h2>
            <p>Add new patterns and responses to train your chatbot.</p>
            <form id="revx-chatbot-training-form">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="revx-chatbot-pattern">Pattern</label></th>
                        <td>
                            <input type="text" id="revx-chatbot-pattern" name="pattern" class="regular-text" placeholder="e.g., how to order">
                            <p class="description">Enter a phrase or keyword that users might type.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="revx-chatbot-response">Response</label></th>
                        <td>
                            <textarea id="revx-chatbot-response" name="response" class="large-text" rows="4" placeholder="e.g., You can place an order by visiting our website and clicking on the 'Order Now' button."></textarea>
                            <p class="description">Enter the response the chatbot should give when it recognizes the pattern.</p>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Add Pattern & Response</button>
                </p>
            </form>
        </div>
        
        <!-- OpenRouter API Tab -->
        <div class="revx-chatbot-tab-content" id="openrouter-tab">
            <h2>OpenRouter API Settings</h2>
            <p>Configure OpenRouter API integration to enhance the chatbot's natural language understanding capabilities.</p>
            <form id="revx-chatbot-openrouter-form">
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="revx-chatbot-openrouter-api-key">API Key</label></th>
                        <td>
                            <input type="text" id="revx-chatbot-openrouter-api-key" name="openrouter_api_key" value="<?php echo esc_attr(get_option('revx_chatbot_openrouter_api_key', '')); ?>" class="regular-text">
                            <p class="description">Enter your OpenRouter API key. You can get one from <a href="https://openrouter.ai/" target="_blank">openrouter.ai</a></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="revx-chatbot-openrouter-model">Model</label></th>
                        <td>
                            <select id="revx-chatbot-openrouter-model" name="openrouter_model">
                                <option value="openai/gpt-3.5-turbo" <?php selected(get_option('revx_chatbot_openrouter_model', 'openai/gpt-3.5-turbo'), 'openai/gpt-3.5-turbo'); ?>>GPT-3.5 Turbo</option>
                                <option value="anthropic/claude-instant-v1" <?php selected(get_option('revx_chatbot_openrouter_model', 'openai/gpt-3.5-turbo'), 'anthropic/claude-instant-v1'); ?>>Claude Instant</option>
                                <option value="google/palm-2-chat-bison" <?php selected(get_option('revx_chatbot_openrouter_model', 'openai/gpt-3.5-turbo'), 'google/palm-2-chat-bison'); ?>>PaLM 2 Chat</option>
                            </select>
                            <p class="description">Select the AI model to use for processing queries. Free tier models are available.</p>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Save API Settings</button>
                </p>
            </form>
            <div class="revx-chatbot-api-info">
                <h3>How It Works</h3>
                <p>The OpenRouter API integration enhances your chatbot's ability to understand complex user queries by:</p>
                <ol>
                    <li>Processing the user's message through the selected AI model</li>
                    <li>Extracting the main intent and entities from the message</li>
                    <li>Using this enhanced understanding to match against your local response data</li>
                </ol>
                <p><strong>Note:</strong> The API is only used to understand the query. All responses still come from your local data.</p>
            </div>
        </div>
    </div>
</div>