/**
 * RevX Chatbot Admin JavaScript
 */

jQuery(document).ready(function($) {
    // Tab switching
    $('.revx-chatbot-tab-button').on('click', function() {
        const tabId = $(this).data('tab');
        
        // Update active tab button
        $('.revx-chatbot-tab-button').removeClass('active');
        $(this).addClass('active');
        
        // Show selected tab content
        $('.revx-chatbot-tab-content').removeClass('active');
        $(`#${tabId}-tab`).addClass('active');
        
        // Load responses if responses tab is selected
        if (tabId === 'responses') {
            loadResponses();
        }
    });
    
    // Training form submission
    $('#revx-chatbot-training-form').on('submit', function(e) {
        e.preventDefault();
        
        const pattern = $('#revx-chatbot-pattern').val().trim();
        const response = $('#revx-chatbot-response').val().trim();
        
        if (pattern === '' || response === '') {
            // Create message container if it doesn't exist
            if ($('#training-message-container').length === 0) {
                $('#training-tab').prepend('<div id="training-message-container" class="notice notice-error"><p>Pattern and response cannot be empty.</p></div>');
            } else {
                $('#training-message-container').removeClass('notice-success notice-info').addClass('notice-error').html('<p>Pattern and response cannot be empty.</p>');
            }
            
            // Show message and hide after 3 seconds
            $('#training-message-container').show();
            setTimeout(function() {
                $('#training-message-container').fadeOut();
            }, 3000);
            
            return;
        }
        
        // Create message container if it doesn't exist
        if ($('#training-message-container').length === 0) {
            $('#training-tab').prepend('<div id="training-message-container" class="notice"></div>');
        }
        
        // Show loading message
        $('#training-message-container').removeClass('notice-success notice-error').addClass('notice-info').html('<p>Saving training data...</p>').show();
        
        $.ajax({
            url: revxChatbotAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'revx_chatbot_train',
                nonce: revxChatbotAdmin.nonce,
                pattern: pattern,
                response: response
            },
            dataType: 'json',
            cache: false,
            success: function(response) {
                if (response && response.success) {
                    $('#training-message-container').removeClass('notice-info notice-error').addClass('notice-success').html('<p>' + response.data.message + '</p>');
                    $('#revx-chatbot-pattern').val('');
                    $('#revx-chatbot-response').val('');
                } else {
                    const errorMsg = (response && response.data && response.data.message) ? response.data.message : 'Unknown error occurred';
                    $('#training-message-container').removeClass('notice-info notice-success').addClass('notice-error').html('<p>' + errorMsg + '</p>');
                }
                
                // Hide message after 3 seconds
                setTimeout(function() {
                    $('#training-message-container').fadeOut();
                }, 3000);
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#training-message-container').removeClass('notice-info notice-success').addClass('notice-error').html('<p>An error occurred while training the chatbot. Please check the console for details.</p>');
                
                // Hide message after 3 seconds
                setTimeout(function() {
                    $('#training-message-container').fadeOut();
                }, 3000);
            }
        });
    });
    
    // Save settings
    $('#revx-chatbot-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get checkbox value manually since unchecked boxes aren't included in serialized data
        const useOpenRouter = $('#revx-chatbot-use-openrouter').is(':checked') ? 1 : 0;
        
        $.ajax({
            url: revxChatbotAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'revx_chatbot_save_settings',
                nonce: revxChatbotAdmin.nonce,
                ...Object.fromEntries(new FormData(this)),
                use_openrouter: useOpenRouter
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert(response.data.message || 'Error saving settings');
                }
            },
            error: function() {
                alert('Error communicating with the server');
            }
        });
    });
    
    // Save OpenRouter API settings
    $('#revx-chatbot-openrouter-form').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: revxChatbotAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'revx_chatbot_save_openrouter_settings',
                nonce: revxChatbotAdmin.nonce,
                ...Object.fromEntries(new FormData(this))
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert(response.data.message || 'Error saving API settings');
                }
            },
            error: function() {
                alert('Error communicating with the server');
            }
        });
    });
    
    // Function to load responses
    function loadResponses() {
        $('#revx-chatbot-responses-container').html('<div class="revx-chatbot-loading">Loading responses...</div>');
        
        $.ajax({
            url: revxChatbotAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'revx_chatbot_get_all_responses',
                nonce: revxChatbotAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayResponses(response.data.responses);
                } else {
                    $('#revx-chatbot-responses-container').html('<p>Failed to load responses.</p>');
                }
            },
            error: function() {
                $('#revx-chatbot-responses-container').html('<p>An error occurred while loading responses.</p>');
            }
        });
    }
    
    // Function to display responses
    function displayResponses(responses) {
        if (!responses || responses.length === 0) {
            $('#revx-chatbot-responses-container').html('<p>No responses found.</p>');
            return;
        }
        
        let html = '<div class="revx-chatbot-responses-list">';
        
        // Add greetings
        html += '<div class="revx-chatbot-response-category">';
        html += '<h3>Greetings</h3>';
        html += '<ul class="revx-chatbot-editable-list">';
        responses.greetings.forEach(function(greeting, index) {
            html += '<li>' + 
                    '<span class="revx-response-text">' + greeting + '</span>' + 
                    '<button type="button" class="revx-edit-response button button-small" ' + 
                    'data-category="greetings" data-index="' + index + '">' + 
                    '<span class="dashicons dashicons-edit"></span> Edit</button>' + 
                    '</li>';
        });
        html += '</ul>';
        html += '</div>';
        
        // Add farewells
        html += '<div class="revx-chatbot-response-category">';
        html += '<h3>Farewells</h3>';
        html += '<ul class="revx-chatbot-editable-list">';
        responses.farewell.forEach(function(farewell, index) {
            html += '<li>' + 
                    '<span class="revx-response-text">' + farewell + '</span>' + 
                    '<button type="button" class="revx-edit-response button button-small" ' + 
                    'data-category="farewell" data-index="' + index + '">' + 
                    '<span class="dashicons dashicons-edit"></span> Edit</button>' + 
                    '</li>';
        });
        html += '</ul>';
        html += '</div>';
        
        // Add fallbacks
        html += '<div class="revx-chatbot-response-category">';
        html += '<h3>Fallbacks</h3>';
        html += '<ul class="revx-chatbot-editable-list">';
        responses.fallback.forEach(function(fallback, index) {
            html += '<li>' + 
                    '<span class="revx-response-text">' + fallback + '</span>' + 
                    '<button type="button" class="revx-edit-response button button-small" ' + 
                    'data-category="fallback" data-index="' + index + '">' + 
                    '<span class="dashicons dashicons-edit"></span> Edit</button>' + 
                    '</li>';
        });
        html += '</ul>';
        html += '</div>';
        
        // Add custom responses
        html += '<div class="revx-chatbot-response-category">';
        html += '<h3>Custom Responses</h3>';
        html += '<table class="revx-chatbot-responses-table">';
        html += '<thead><tr><th>Patterns</th><th>Responses</th></tr></thead>';
        html += '<tbody>';
        
        responses.responses.forEach(function(item, itemIndex) {
            html += '<tr>';
            html += '<td>';
            item.patterns.forEach(function(pattern, patternIndex) {
                html += '<div class="revx-pattern-item">' + 
                        '<span class="revx-response-text">' + pattern + '</span>' + 
                        '<button type="button" class="revx-edit-response button button-small" ' + 
                        'data-category="responses" data-index="' + itemIndex + '" ' + 
                        'data-pattern-id="' + patternIndex + '">' + 
                        '<span class="dashicons dashicons-edit"></span> Edit</button>' + 
                        '</div>';
            });
            html += '</td>';
            html += '<td>';
            item.responses.forEach(function(response, responseIndex) {
                html += '<div class="revx-response-item">' + 
                        '<span class="revx-response-text">' + response + '</span>' + 
                        '<button type="button" class="revx-edit-response button button-small" ' + 
                        'data-category="responses" data-index="' + itemIndex + '" ' + 
                        'data-response-id="' + responseIndex + '">' + 
                        '<span class="dashicons dashicons-edit"></span> Edit</button>' + 
                        '</div>';
            });
            html += '</td>';
            html += '</tr>';
        });
        
        html += '</tbody></table>';
        html += '</div>';
        
        html += '</div>';
        
        // Add edit modal
        html += '<div id="revx-edit-response-modal" class="revx-modal">' +
                '<div class="revx-modal-content">' +
                '<span class="revx-modal-close">&times;</span>' +
                '<h3>Edit Response</h3>' +
                '<form id="revx-edit-response-form">' +
                '<input type="hidden" id="revx-edit-category" name="category" value="">' +
                '<input type="hidden" id="revx-edit-index" name="index" value="">' +
                '<input type="hidden" id="revx-edit-pattern-id" name="pattern_id" value="">' +
                '<input type="hidden" id="revx-edit-response-id" name="response_id" value="">' +
                '<div class="revx-form-group">' +
                '<label for="revx-edit-text">Response Text:</label>' +
                '<textarea id="revx-edit-text" name="text" rows="4" class="large-text"></textarea>' +
                '</div>' +
                '<div class="revx-form-actions">' +
                '<button type="submit" class="button button-primary">Save Changes</button>' +
                '<button type="button" class="button revx-cancel-edit">Cancel</button>' +
                '</div>' +
                '</form>' +
                '</div>' +
                '</div>';
        
        $('#revx-chatbot-responses-container').html(html);
        
        // Initialize edit buttons and modal functionality
        initResponseEditing();
    }
    
    // Function to initialize response editing functionality
    function initResponseEditing() {
        // Edit button click handler
        $('.revx-edit-response').on('click', function() {
            const category = $(this).data('category');
            const index = $(this).data('index');
            const patternId = $(this).data('pattern-id');
            const responseId = $(this).data('response-id');
            const text = $(this).siblings('.revx-response-text').text();
            
            // Populate the form
            $('#revx-edit-category').val(category);
            $('#revx-edit-index').val(index);
            $('#revx-edit-pattern-id').val(patternId !== undefined ? patternId : '');
            $('#revx-edit-response-id').val(responseId !== undefined ? responseId : '');
            $('#revx-edit-text').val(text);
            
            // Show the modal
            $('#revx-edit-response-modal').show();
        });
        
        // Close modal when clicking the X
        $('.revx-modal-close, .revx-cancel-edit').on('click', function() {
            $('#revx-edit-response-modal').hide();
        });
        
        // Close modal when clicking outside of it
        $(window).on('click', function(event) {
            if ($(event.target).is('#revx-edit-response-modal')) {
                $('#revx-edit-response-modal').hide();
            }
        });
        
        // Handle form submission
        $('#revx-edit-response-form').on('submit', function(e) {
            e.preventDefault();
            
            const category = $('#revx-edit-category').val();
            const index = $('#revx-edit-index').val();
            const patternId = $('#revx-edit-pattern-id').val();
            const responseId = $('#revx-edit-response-id').val();
            const text = $('#revx-edit-text').val().trim();
            
            if (text === '') {
                alert('Response text cannot be empty.');
                return;
            }
            
            // Show loading message
            const modalContent = $('.revx-modal-content');
            modalContent.append('<div class="revx-loading">Saving changes...</div>');
            
            // Send AJAX request to update the response
            $.ajax({
                url: revxChatbotAdmin.ajaxurl,
                type: 'POST',
                data: {
                    action: 'revx_chatbot_update_response',
                    nonce: revxChatbotAdmin.nonce,
                    category: category,
                    index: index,
                    pattern_id: patternId,
                    response_id: responseId,
                    text: text
                },
                success: function(response) {
                    $('.revx-loading').remove();
                    
                    if (response.success) {
                        // Close the modal
                        $('#revx-edit-response-modal').hide();
                        
                        // Reload responses to show the updated data
                        loadResponses();
                        
                        // Show success message
                        if ($('#response-message-container').length === 0) {
                            $('#responses-tab').prepend('<div id="response-message-container" class="notice notice-success"><p>' + response.data.message + '</p></div>');
                        } else {
                            $('#response-message-container').removeClass('notice-error').addClass('notice-success').html('<p>' + response.data.message + '</p>');
                        }
                        
                        // Hide message after 3 seconds
                        $('#response-message-container').show();
                        setTimeout(function() {
                            $('#response-message-container').fadeOut();
                        }, 3000);
                    } else {
                        const errorMsg = (response.data && response.data.message) ? response.data.message : 'Unknown error occurred';
                        alert('Error: ' + errorMsg);
                    }
                },
                error: function() {
                    $('.revx-loading').remove();
                    alert('An error occurred while updating the response. Please try again.');
                }
            });
        });
    }
});